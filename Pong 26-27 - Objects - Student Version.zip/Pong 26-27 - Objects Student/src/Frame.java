import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

/** Sets up the window and game loop. Students should work in Pong.java. */
public class Frame extends JPanel implements KeyListener, ActionListener {

	private static final int WINDOW_WIDTH = 800;
	private static final int WINDOW_HEIGHT = 600;
	private static final int MILLISECONDS_PER_FRAME = 16;

	private final Timer timer;

	public Frame() {
		setBackground(Color.BLACK);

		JFrame frame = new JFrame("Pong - Objects Student");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		frame.add(this);
		frame.addKeyListener(this);

		timer = new Timer(MILLISECONDS_PER_FRAME, this);
		timer.start();
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		repaint();
	}

	@Override
	public void keyPressed(KeyEvent key) {
		// Pong.java will override this method.
	}

	@Override
	public void keyReleased(KeyEvent key) {
		// Pong.java will override this method.
	}

	@Override
	public void keyTyped(KeyEvent key) {
		// Pong.java will override this method.
	}
}

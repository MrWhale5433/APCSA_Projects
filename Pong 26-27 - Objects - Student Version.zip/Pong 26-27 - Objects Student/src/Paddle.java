import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/** Represents one Pong paddle. */
public class Paddle {

	// Instance variables: each Paddle object has its own values.
	private int x;
	private int y;
	private int width;
	private int height;
	private int speed;
	private Color color;

	/** Creates a standard-sized white paddle. */
	public Paddle(int x, int y) {
		this(x, y, 20, 100, 5, Color.WHITE);
	}

	/** Creates a paddle with the supplied starting values. */
	public Paddle(int x, int y, int width, int height, int speed, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.speed = speed;
		this.color = color;
	}

	/** Moves the paddle upward. */
	public void moveUp() {
		y -= speed;
	}

	/** Moves the paddle downward. */
	public void moveDown() {
		y += speed;
	}

	/** Keeps this paddle inside the board. */
	public void stayOnScreen(int boardHeight) {
		if (y < 0) {
			y = 0;
		} else if (y + height > boardHeight) {
			y = boardHeight - height;
		}
	}

	/** Draws this Paddle object. */
	public void paint(Graphics pen) {
		pen.setColor(color);
		pen.fillRect(x, y, width, height);
	}

	/** Returns a rectangle for collision detection in a later lesson. */
	public Rectangle getBounds() {
		return new Rectangle(x, y, width, height);
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
}

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/** Represents the Pong ball. */
public class Ball {

	// Instance variables: every Ball object gets its own copy of these values.
	private int x;
	private int y;
	private int size;
	private int xSpeed;
	private int ySpeed;
	private Color color;

	/** Creates a standard-sized white ball with a starting velocity. */
	public Ball(int x, int y) {
		this(x, y, 30, 3, 4, Color.WHITE);
	}

	/** Creates a ball with the supplied starting values. */
	public Ball(int x, int y, int size, int xSpeed, int ySpeed, Color color) {
		this.x = x;
		this.y = y;
		this.size = size;
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
		this.color = color;
	}

	/** Moves the ball one frame using its current velocity. */
	public void move() {
		x += xSpeed;
		y += ySpeed;
	}

	/** Bounces the ball off the four edges of the board. */
	public void bounceOffEdges(int boardWidth, int boardHeight) {
		if (x <= 0) {
			x = 0;
			xSpeed = Math.abs(xSpeed);
		} else if (x + size >= boardWidth) {
			x = boardWidth - size;
			xSpeed = -Math.abs(xSpeed);
		}

		if (y <= 0) {
			y = 0;
			ySpeed = Math.abs(ySpeed);
		} else if (y + size >= boardHeight) {
			y = boardHeight - size;
			ySpeed = -Math.abs(ySpeed);
		}
	}

	/** Reverses the horizontal part of the ball's velocity. */
	public void reverseX() {
		xSpeed *= -1;
	}

	/** Reverses the vertical part of the ball's velocity. */
	public void reverseY() {
		ySpeed *= -1;
	}

	/** Draws this Ball object. */
	public void paint(Graphics pen) {
		pen.setColor(color);
		pen.fillOval(x, y, size, size);
	}

	/** Returns a rectangle for collision detection in a later lesson. */
	public Rectangle getBounds() {
		return new Rectangle(x, y, size, size);
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getSize() {
		return size;
	}
}

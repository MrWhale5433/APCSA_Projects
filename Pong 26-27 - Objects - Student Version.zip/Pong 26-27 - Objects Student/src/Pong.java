import java.awt.Graphics;
import java.awt.event.KeyEvent;

/**
 * Student worksheet: complete the numbered steps in order.
 *
 * Students should make changes in this file. Ball.java and Paddle.java are
 * the classes whose objects this file will create and use.
 */
public class Pong extends Frame {

	/*
	 * STEP 1: Declare the object variables.
	 *
	 * Declare exactly THREE object references: one Ball reference and two
	 * Paddle references. Name them ball, leftPaddle, and rightPaddle. Use the
	 * class name as the type for each reference.
	 */

	/*
	 * STEP 5: Add four boolean instance variables to remember whether each
	 * paddle movement key is being held. You will use these in update().
	 */

	public Pong() {
		/*
		 * STEP 2: Construct the objects.
		 *
		 * Write exactly THREE object-creation statements here, one per object.
		 * Use the two-parameter constructors. Choose a starting position near
		 * the middle for the ball and one position near each side for the
		 * paddles. Check Ball.java and Paddle.java to see the constructor forms.
		 */

	}

	/* paint is called roughly 60 times per second. */
	@Override
	public void paint(Graphics pen) {
		super.paintComponent(pen); // Do not delete: clears the old frame.

		/*
		 * STEP 3: In this order:
		 *   1. Make ONE call to update().
		 *   2. Make THREE paint calls: one for the ball and one for each paddle.
		 */

	}

	/** Updates the objects for one frame. */
	public void update() {
		/*
		 * STEP 4: Add exactly TWO method calls for ball: ask it to move, then
		 * ask it to bounce off the edges. Pass the panel width and height to the
		 * edge-bouncing method.
		 */

		/*
		 * STEP 6: Use FOUR if statements, one for each boolean variable, to move
		 * the paddles. Then make TWO boundary-method calls so both paddles stay
		 * on the board. Pass the panel height to those methods.
		 */

	}

	/** Records which movement keys are currently being held down. */
	@Override
	public void keyPressed(KeyEvent key) {
		/*
		 * STEP 7: Handle FOUR keys and set the matching boolean to true:
		 *   W = left paddle up       S = left paddle down
		 *   Up Arrow = right up      Down Arrow = right down
		 *
		 * Use key.getKeyCode() with if statements or a switch statement.
		 */

	}

	/** Stops paddle movement when a movement key is released. */
	@Override
	public void keyReleased(KeyEvent key) {
		/* STEP 7 continued: Handle the same FOUR keys and set each boolean to
		 * false. */

	}

	@Override
	public void keyTyped(KeyEvent key) {
		// This game uses keyPressed and keyReleased instead.
	}

	/*
	 * STEP 8: After the game works, experiment with the longer constructors
	 * and the helper methods in Ball.java and Paddle.java. Change one thing at
	 * a time and observe what happens.
	 */

	public static void main(String[] args) {
		new Pong();
	}
}

# Pong 26-27 - Objects Student

This is the student worksheet for the object-oriented version of Pong. Work
primarily in `src/Pong.java`. `Ball.java`, `Paddle.java`, and `Frame.java` are
provided support classes.

Open `Pong.java` and complete the numbered steps in order. The starter file
will open a game window, but it will not display the game until the object
creation and drawing steps are completed.

1. Declare exactly three object references: one `Ball` and two `Paddle` references.
2. Create exactly three objects in `Pong()`, one object per line.
3. Add one `update` call and three object `paint` calls in `paint`.
4. Add exactly two ball method calls in `update`: movement and edge bouncing.
5. Add four boolean instance variables for the four paddle movement keys.
6. Add four paddle movement checks and two boundary-method calls in `update`.
7. Handle four keys in `keyPressed` and the same four keys in `keyReleased`.
8. Experiment with the constructors and methods after the game works.

Controls after the steps are complete:

- Left paddle: `W` and `S`
- Right paddle: Up Arrow and Down Arrow

The completed `Pong 26-27 - Objects` project is available in the same Eclipse
workspace as a teacher/reference copy.
